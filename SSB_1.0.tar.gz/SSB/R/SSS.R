#'SSS object.
#'
#' @param x SSS object
#' @param ... ignored
#'@noRd
#importFrom("stats", "approx", "median", "pnorm", "qnorm", "quantile")

################################################################################
#Function:
#Compute The Exact (Standard) Sample Size (S):
# m sample size of interest
# d error margin
# alfa siginificance level
# q order of quantile of interest to estimate
# Xp the pilot sample size
################################################################################
#Begin Function
SSS<-function(m=NULL,d=NULL,alfa,q,Xp,N=NULL){
 z=qnorm(1-alfa/2)
 varr<-q*(1-q)
 np<-length(Xp)
 k<-round(sqrt(np))
 #Compute the q-th sample quantile
 sxnp<-sort(Xp)
 r<-floor(np*q)+1
 xnq<-sxnp[r]
 lsup<-sxnp[r+k]
 linf<-sxnp[r-k]
 if((r+k)>np){lsup<-sxnp[np]}
 if((r-k)<1){linf<-sxnp[1]}
 AA<-(lsup-linf)
 smk<-(np*(AA))/(2*k)
 if(is.null(m)){
  outmd<- ceiling(((z^2)*varr*(smk^(2))/(d^2)))
 }else{
  if(is.null(N)){
 outmd<-sqrt((z^2)*varr*(smk^(2))/m)
 }else{
  outmd<-sqrt((z^2)*((1-(m/N))*varr)*(smk^(2))/m)
 }
 }
 return(outmd)
}
#End Function
