#' @export
#' @importFrom stats approx median pnorm qnorm quantile
#' @importFrom bootstrap bcanon

################################################################################
#Function:
#The Sample Size using the procedure SSB:
################################################################################
#Begin Function
SSB<-function(y=y,m=c(5,10),errormarginset=NULL,B=20000,alpha=0.05,q=0.50,N=1000000){
 na<-length(m)
 ### Declare Variables
 mediaam=numeric(na)
 damboot=numeric(na)
 ### Loop sample size
 for(i in 1:na){ # Loop
   mediaam[i]= quantile(y,probs=c(0.5))
   xnamedboot=numeric(B)
   for(j in 1:B){  # Loop bootstrap
    ii=sample(1:length(y),m[i],replace=T)
    auxbooty=y[ii]
    xnamedboot[j]=quantile(auxbooty,probs=c(q))
   }
   ## Compute do Error margin
   #BCA bootstrap confidence interval
   results <- bca(xnamedboot, conf.level =1-alpha)
   linfboot<- results[1]
   lsupboot<- results[2]
   #Width
   Amplitude=lsupboot-linfboot
   medboot=median(xnamedboot)
   # Error margin
   damboot[i]=(Amplitude/2)*sqrt(1-(m[i]/N))
 }
 if(is.null(errormarginset)){
    out<-list(m,damboot)
    names(out)[1]="Sample size grid:"
    names(out)[2]="Error margin E grid:"
 }else{
    interplinear_n = approx(damboot, m, xout=errormarginset)
    interplinear_n$y=round(interplinear_n$y)
    out<-list(m,damboot,interplinear_n$y,interplinear_n$x)
    names(out)[1]="Sample size grid:"
    names(out)[2]="Error margin E grid:"
    names(out)[3]="Sample size n = "
    names(out)[4]="Error margin desired E = "
 }
 return(out)
}
#End Function
